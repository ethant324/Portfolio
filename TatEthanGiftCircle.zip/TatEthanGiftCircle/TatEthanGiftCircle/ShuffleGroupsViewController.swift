//
//  ShuffleGroupsViewController.swift
//  TatEthanGiftCircle
//
//  Created by Ethan Tat on 12/15/21.
//

// Referenced https://www.youtube.com/watch?v=EsheQe6U_WE

import UIKit
import FirebaseDatabase
import FirebaseAuth

var groupNames = [String]()

class ShuffleGroupsViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return groupNames.count
    }
    func pickerView(_pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return groupNames[row]
    }

    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var doneButton: UIBarButtonItem!
    @IBOutlet weak var hostedGroupsPicker: UIPickerView!
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let currentUser = Auth.auth().currentUser
        let ongoingUser = Database.database().reference().child("users").child(currentUser!.uid)
        ongoingUser.child("hostedGroups").child("groupName").getData(completion: {
            error, snap in
            guard error == nil else
            {
                print("Error!")
                return
            }
            let groups = snap.value as? [String: String]
            let groupNamesInfo = groups!.keys
            for group in groupNamesInfo
            {
                groupNames.append(group)
            }
        })
    }
    
    /*func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return groupNames.count
    }
    func pickerView(_pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return groupNames[row]
    }
     */
    
    /*@IBAction func doneButtonPressed(_ sender: UIBarButtonItem) {
        let row = hostedGroupsPicker.selectedRow(inComponent: 0)
        let group = groupNames[row]
        dismiss(animated: true, completion: nil)
    }
    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    } */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

/*extension ViewController: UIPickerViewDataSource
{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return groupNames.count
    }
    func pickerView(_pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return groupNames[row]
    }
}

extension ViewController: UIPickerViewDelegate
{
    
} */
