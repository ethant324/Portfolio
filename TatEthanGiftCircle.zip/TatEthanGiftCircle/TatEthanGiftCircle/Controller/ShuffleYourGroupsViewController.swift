//
//  ShuffleYourGroupsViewController.swift
//  TatEthanGiftCircle
//
//  Created by Student on 12/15/21.
//

import UIKit
import FirebaseDatabase

class ShuffleYourGroupsViewController: UIViewController {

    @IBOutlet weak var passcodeTextField: UITextField!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var doneButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // Shuffles and assigns people for gift exchange and switches to home screen
    @IBAction func doneButtonPressed(_ sender: UIBarButtonItem) {
        if let passcode = passcodeTextField.text
        {
            Database.database().reference().child("groups").child("\(passcode)").child("members").getData(completion: {
                error, snap in
                guard error == nil else
                {
                    print("Error!")
                    return
                }
                var groupMembers =  [String]()
                let memberIDs = snap.value as? [String: Any]
                let members = memberIDs!.keys
                for member in members
                {
                    groupMembers.append(member)
                }
                var giftees = [Int]()
                for index in 0..<groupMembers.count
                {
                    giftees.append(groupMembers.count - index - 1)
                }
                for members in 0..<groupMembers.count
                {
                    let currentMember = Database.database().reference().child("groups").child("\(passcode)").child("members")
                    currentMember.child("\(groupMembers[members])").child("giftee").setValue(groupMembers[giftees[members]])
                }
            })
        }
        dismiss(animated: true, completion: nil)
    }
    
    // Switches to home screen
    @IBAction func cancelButtonPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
