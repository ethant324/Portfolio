//
//  CreateAccountViewController.swift
//  TatEthanGiftCircle
//
//  Created by Ethan Tat on 12/10/21.
//

import FirebaseAuth
import FirebaseDatabase
import UIKit

class CreateAccountViewController: UIViewController {
    
    @IBOutlet weak var accountFullNameTextField: UITextField!
    @IBOutlet weak var accountEmailTextField: UITextField!
    @IBOutlet weak var accountPasswordTextField: UITextField!
    @IBOutlet weak var createAccountButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // Ensures that the necessary information is given
    @IBAction func accountFullNameTextFieldEdited(_ sender: UITextField) {
        if let accountFullName = accountFullNameTextField.text
        {
            let accountEmail = accountEmailTextField.text ?? ""
            let accountPassword = accountPasswordTextField.text ?? ""
            if accountFullName.count > 0 && accountEmail.count > 0 && accountPassword.count > 0
            {
                createAccountButton.isEnabled = true
            }
            else
            {
                createAccountButton.isEnabled = false
            }
        }
    }
    
    // Ensures that the necessary information is given
    @IBAction func accountEmailTextFieldEdited(_ sender: UITextField) {
        if let accountEmail = accountEmailTextField.text
        {
            let accountFullName = accountFullNameTextField.text ?? ""
            let accountPassword = accountPasswordTextField.text ?? ""
            if accountEmail.count > 0 && accountFullName.count > 0 && accountPassword.count > 0
            {
                createAccountButton.isEnabled = true
            }
            else
            {
                createAccountButton.isEnabled = false
            }
        }
    }
    
    // Ensures that the necessary information is given
    @IBAction func accountPasswordTextFieldEdited(_ sender: UITextField) {
        if let accountPassword = accountPasswordTextField.text
        {
            let accountFullName = accountFullNameTextField.text ?? ""
            let accountEmail = accountEmailTextField.text ?? ""
            if accountFullName.count > 0 && accountEmail.count > 0 && accountPassword.count > 0
            {
                createAccountButton.isEnabled = true
            }
            else
            {
                createAccountButton.isEnabled = false
            }
        }
    }
    
    // Referenced Bennet Lee's Firebase Lecture and instructions from https://firebase.google.com
    // New account is created with given credentials
    @IBAction func createAccountButtonPressed(_ sender: Any) {
        if let accountFullName = accountFullNameTextField.text, let accountEmail = accountEmailTextField.text, let accountPassword = accountPasswordTextField.text {
            Auth.auth().createUser(withEmail: accountEmail, password: accountPassword) { User, error in
                if error == nil && User != nil
                {
                    let createdUser = Database.database().reference().child("users").child(User!.user.uid)
                    createdUser.setValue(["fullName": "\(accountFullName)", "id": "\(User!.user.uid)", "email": "\(accountEmail)"])
                    // Referenced https://firebase.google.com/docs/auth/web/manage-users
                    let profileChangeRequest = User?.user.createProfileChangeRequest()
                    profileChangeRequest?.displayName = accountFullName
                    profileChangeRequest?.commitChanges {
                        error in
                    }
                }
            }
            // Switches to new view controller
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let newVC = storyboard.instantiateViewController(withIdentifier: "HomeScreenViewController")
            newVC.modalPresentationStyle = .fullScreen
            present(newVC, animated: true, completion: nil)
        }
    }
    
    // Dismisses the view controller and goes back to the login screen
    @IBAction func cancelButtonPressed(_ sender: Any) {
        accountEmailTextField.text = ""
        accountPasswordTextField.text = ""
        dismiss(animated: true, completion: nil)
    }
    
    // When keyboard return key is pressed for text field, dismisses keyboard
    @IBAction func accountFullNameTextFieldReturnPressed(_ sender: UITextField) {
        accountFullNameTextField.resignFirstResponder()
        accountEmailTextField.becomeFirstResponder()
    }
    // When keyboard return key is pressed for text field, dismisses keyboard
    @IBAction func accountEmailTextFieldReturnPressed(_ sender: UITextField) {
        accountEmailTextField.resignFirstResponder()
        accountPasswordTextField.becomeFirstResponder()
    }
    // When keyboard return key is pressed for text field, dismisses keyboard
    @IBAction func accountPasswordTextFieldReturnPressed(_ sender: UITextField) {
        accountPasswordTextField.resignFirstResponder()
    }
    // When background is tapped while on keyboard, gets rid of it
    @IBAction func backgroundTapped(_ sender: UITapGestureRecognizer) {
        accountEmailTextField.resignFirstResponder()
        accountPasswordTextField.resignFirstResponder()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
