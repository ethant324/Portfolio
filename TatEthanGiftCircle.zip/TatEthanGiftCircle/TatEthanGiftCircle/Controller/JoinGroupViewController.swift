//
//  JoinGroupViewController.swift
//  TatEthanGiftCircle
//
//  Created by Ethan Tat on 12/14/21.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth

class JoinGroupViewController: UIViewController {

    @IBOutlet weak var joinGroupPromptLabel: UILabel!
    @IBOutlet weak var passcodeTextField: UITextField!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var doneButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // Switches to home screen
    @IBAction func cancelButtonPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
    }
    
    // User joins group, switches to home screen
    @IBAction func doneButtonPressed(_ sender: Any) {
        // Referenced https://firebase.google.com/docs/database/ios/read-and-write?authuser=0, https://www.youtube.com/watch?v=RMudKhNY0sI, https://www.youtube.com/watch?v=tpsffoRh9u0
        var groups = [String: Any]().keys
        var wrongPasscode = false
        let group = Database.database().reference()
        group.child("groups").getData(completion: {
            error, snap in
            guard error == nil else
            {
                print("Error!")
                return
            }
            let groupPasscodes = snap.value as? [String: Any]
            groups = groupPasscodes!.keys
            for oneGroup in groups
            {
                if(oneGroup == self.passcodeTextField.text)
                {
                    wrongPasscode = false
                    break
                }
                else
                {
                    wrongPasscode = true
                }
            }
            if wrongPasscode == false
            {
                if let passcode = self.passcodeTextField.text
                {
                    let currentUser = Auth.auth().currentUser
                    let currentUserFullName = currentUser?.displayName ?? ""
                    let group = Database.database().reference().child("groups").child("\(passcode)")
                    group.child("members").child(currentUserFullName).setValue(["fullName": "\(currentUserFullName)", "id": "\(currentUser!.uid)"])
                    group.child("members").child(currentUserFullName).child("isHost").setValue(false)
                    group.child("groupName").getData(completion: {
                        errorTwo, snapTwo in
                        guard error == nil else
                        {
                            print("Error!")
                            return
                        }
                        let groupName = snapTwo.value as? String ?? ""
                        let member = Database.database().reference().child("users").child(currentUser!.uid)
                        member.child("groups").child("\(passcode)").child("groupName").setValue(groupName)
                    })
                }
            }
            if wrongPasscode == false
            {
                self.dismiss(animated: true, completion: nil)
            }
        })
    }
    
    // Return key pressed and keyboard is dismissed
    @IBAction func passcodeTextFieldReturnPressed(_ sender: UITextField) {
        passcodeTextField.resignFirstResponder()
    }
    
    // Background is tapped and keyboard is dismissed
    @IBAction func backgroundTapped(_ sender: UITapGestureRecognizer) {
        passcodeTextField.resignFirstResponder()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
