//
//  RevealInputViewController.swift
//  TatEthanGiftCircle
//
//  Created by Student on 12/15/21.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth

class RevealInputViewController: UIViewController {
    
    @IBOutlet weak var passcodeTextField: UITextField!
    @IBOutlet weak var nextButton: UIBarButtonItem!
    @IBOutlet weak var revealLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // Reveals to the user who their person is
    @IBAction func revealButtonPressed(_ sender: UIButton) {
        if let passcode = passcodeTextField.text
        {
            let currentUser = Auth.auth().currentUser
            let currentUserFullName = currentUser!.displayName ?? ""
            Database.database().reference().child("groups").child("\(passcode)").child("members").child("\(currentUserFullName)").child("giftee").getData(completion: {
                error, snap in
                guard error == nil else
                {
                    print("Error!")
                    return
                }
                let giftee = snap.value as? String ?? ""
                self.revealLabel.text = "Your person is \(giftee)!"
            })
        }
    }
    
    // Dismisses the view controller
    @IBAction func doneButtonPressed(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
