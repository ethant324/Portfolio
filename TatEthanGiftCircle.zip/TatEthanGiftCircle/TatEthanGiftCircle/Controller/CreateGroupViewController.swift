//
//  CreateGroupViewController.swift
//  TatEthanGiftCircle
//
//  Created by Ethan Tat on 12/9/21.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth

class CreateGroupViewController: UIViewController {

    
    @IBOutlet weak var createGroupPromptLabel: UILabel!
    @IBOutlet weak var passcodeTextField: UITextField!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var doneButton: UIBarButtonItem!
    @IBOutlet weak var groupNamePromptLabel: UILabel!
    @IBOutlet weak var groupNameTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        doneButton.isEnabled = false
        // Do any additional setup after loading the view.
    }
    
    // Return key pressed on keyboard, keyboard is dismissed
    @IBAction func passcodeTextFieldReturnPressed(_ sender: UITextField) {
        passcodeTextField.resignFirstResponder()
        groupNameTextField.becomeFirstResponder()
    }

    // Return key pressed on keyboard, keyboard is dismissed
    @IBAction func groupNameTextFieldReturnPressed(_ sender: UITextField) {
        groupNameTextField.resignFirstResponder()
    }
    
    // Background tapped and keyboard is dismissed
    @IBAction func backgroundTapped(_ sender: Any) {
        passcodeTextField.resignFirstResponder()
        groupNameTextField.resignFirstResponder()
    }
    
    // Checks to ensure all necessary information is there
    @IBAction func passcodeTextFieldEdited(_ sender: UITextField) {
        if let passcode = passcodeTextField.text {
            let groupName = groupNameTextField.text ?? ""
            if passcode.count == 4 && groupName.count > 0
            {
                doneButton.isEnabled = true
            }
            else
            {
                doneButton.isEnabled = false
            }
        }
    }
    
    // Checks to ensure all necessary information is there
    @IBAction func groupNameTextFieldEdited(_ sender: UITextField) {
        if let groupName = groupNameTextField.text
        {
            let passcode = passcodeTextField.text ?? ""
            if groupName.count > 0 && passcode.count > 0
            {
                doneButton.isEnabled = true
            }
            else
            {
                doneButton.isEnabled = false
            }
        }
    }
    
    // Switches to home screen
    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    // Switches to home screen and creates group
    @IBAction func doneButtonPressed(_ sender: UIBarButtonItem) {
        if let passcode = passcodeTextField.text, let groupName = groupNameTextField.text
        {
            let createdGroup = Database.database().reference().child("groups").child("\(passcode)")
            createdGroup.setValue(["passcode": "\(passcode)", "groupName": "\(groupName)"])
            let currentUser = Auth.auth().currentUser
            let currentUserFullName = currentUser?.displayName ?? ""
            createdGroup.child("members").child(currentUserFullName).setValue(["fullName": "\(currentUserFullName)", "id": currentUser!.uid])
            createdGroup.child("members").child(currentUserFullName).child("isHost").setValue(true)
            let hostMember = Database.database().reference().child("users").child(currentUser!.uid)
            hostMember.child("hostedGroups").child("groupNames").child(groupName).setValue(passcode)
            hostMember.child("groups").child("groupNames").child(groupName).setValue(passcode)
        }
        dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
