//
//  ViewController.swift
//  TatEthanGiftCircle
//
//  Created by Ethan Tat on 12/9/21.
//

import Firebase
import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var accountEmailTextField: UITextField!
    @IBOutlet weak var accountPasswordTextField: UITextField!
    @IBOutlet weak var logInButton: UIButton!
    @IBOutlet weak var createAccountButton: UIButton!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        accountEmailTextField.delegate = self
        accountPasswordTextField.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        // Checks to see if user is already logged in, if so logs them back into app
        Auth.auth().addStateDidChangeListener({(auth: Auth, user: User?) in
            if user != nil
            {
                // Referenced https://developer.apple.com/documentation/uikit/view_controllers/showing_and_hiding_view_controllers for switching to different view controllers
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let newVC = storyboard.instantiateViewController(withIdentifier: "HomeScreenViewController")
                newVC.modalPresentationStyle = .fullScreen
                self.present(newVC, animated: true, completion: nil)
            }
        })
    }
    
    @IBAction func logInButtonPressed(_ sender: Any) {
        // Signs in user and switches to home screen
        if let accountEmail = accountEmailTextField.text, let accountPassword = accountPasswordTextField.text
        {
            Auth.auth().signIn(withEmail: accountEmail, password: accountPassword) { (user, error) in
                if error == nil
                {
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let newVC = storyboard.instantiateViewController(withIdentifier: "HomeScreenViewController")
                    newVC.modalPresentationStyle = .fullScreen
                    self.present(newVC, animated: true, completion: nil)
                }
            }
        }
        
    }

    
    // Return key pressed when on accountEmailTextField
    @IBAction func accountEmailTextFieldReturnPressed(_ sender: UITextField) {
        accountEmailTextField.resignFirstResponder()
        accountPasswordTextField.becomeFirstResponder()
    }
    // Return key pressed when on accountPasswordTextField
    @IBAction func accountPasswordTextFieldReturnPressed(_ sender: UITextField) {
        accountPasswordTextField.resignFirstResponder()
    }
    // Background tapped when keyboard is active, gets rid of it
    @IBAction func BackgroundTapped(_ sender: UITapGestureRecognizer) {
        accountEmailTextField.resignFirstResponder()
        accountPasswordTextField.resignFirstResponder()
    }
}

